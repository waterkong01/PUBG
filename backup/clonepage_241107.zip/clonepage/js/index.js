function updateTime() {
    const now = new Date();

    // UTC 날짜와 시간
    const utcYear = now.getUTCFullYear();
    const utcMonth = (now.getUTCMonth() + 1).toString().padStart(2, '0'); // 월은 0부터 시작하므로 +1
    const utcDate = now.getUTCDate().toString().padStart(2, '0');
    const utcHours = now.getUTCHours().toString().padStart(2, '0');
    const utcMinutes = now.getUTCMinutes().toString().padStart(2, '0');
    const utcSeconds = now.getUTCSeconds().toString().padStart(2, '0');
    const utcTime = `${utcYear}.${utcMonth}.${utcDate} ${utcHours}:${utcMinutes}:${utcSeconds}`;

    // KST 날짜와 시간 (UTC+9)
    const kstDate = new Date(now.getTime() + 9 * 60 * 60 * 1000); // UTC에 9시간을 더한 시간
    const kstYear = kstDate.getUTCFullYear();
    const kstMonth = (kstDate.getUTCMonth() + 1).toString().padStart(2, '0');
    const kstDay = kstDate.getUTCDate().toString().padStart(2, '0');
    const kstHours = kstDate.getUTCHours().toString().padStart(2, '0');
    const kstMinutes = kstDate.getUTCMinutes().toString().padStart(2, '0');
    const kstSeconds = kstDate.getUTCSeconds().toString().padStart(2, '0');
    const kstTime = `${kstYear}.${kstMonth}.${kstDay} ${kstHours}:${kstMinutes}:${kstSeconds}`;

    // HTML에 표시
    document.getElementById("utc_time").textContent = utcTime;
    document.getElementById("kst_time").textContent = kstTime;
}

// 처음 로드 시 시간 업데이트
updateTime();

// 1초마다 시간 업데이트
setInterval(updateTime, 1000);





const header = document.querySelector('header');
const sec1 = document.querySelector('.sec1');

window.addEventListener('scroll', function() {
    if (window.scrollY >= sec1.offsetTop) {
        header.style.top = "-180px";
    } else {
        header.style.top = "0";
    }
});