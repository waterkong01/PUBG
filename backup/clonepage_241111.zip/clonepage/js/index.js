function updateTime() {
    const now = new Date();

    // UTC 날짜와 시간
    const utcYear = now.getUTCFullYear();
    const utcMonth = (now.getUTCMonth() + 1).toString().padStart(2, '0'); // 월은 0부터 시작하므로 +1
    const utcDate = now.getUTCDate().toString().padStart(2, '0');
    const utcHours = now.getUTCHours().toString().padStart(2, '0');
    const utcMinutes = now.getUTCMinutes().toString().padStart(2, '0');
    const utcSeconds = now.getUTCSeconds().toString().padStart(2, '0');
    const utcTime = `${utcYear}.${utcMonth}.${utcDate} ${utcHours}:${utcMinutes}:${utcSeconds}`;

    // KST 날짜와 시간 (UTC+9)
    const kstDate = new Date(now.getTime() + 9 * 60 * 60 * 1000); // UTC에 9시간을 더한 시간
    const kstYear = kstDate.getUTCFullYear();
    const kstMonth = (kstDate.getUTCMonth() + 1).toString().padStart(2, '0');
    const kstDay = kstDate.getUTCDate().toString().padStart(2, '0');
    const kstHours = kstDate.getUTCHours().toString().padStart(2, '0');
    const kstMinutes = kstDate.getUTCMinutes().toString().padStart(2, '0');
    const kstSeconds = kstDate.getUTCSeconds().toString().padStart(2, '0');
    const kstTime = `${kstYear}.${kstMonth}.${kstDay} ${kstHours}:${kstMinutes}:${kstSeconds}`;

    // HTML에 표시
    document.getElementById("utc_time").textContent = utcTime;
    document.getElementById("kst_time").textContent = kstTime;
}

// 처음 로드 시 시간 업데이트
updateTime();

// 1초마다 시간 업데이트
setInterval(updateTime, 1000);





const header = document.querySelector('header');
const sec1 = document.querySelector('.sec1');

let lastScrollY = window.scrollY;

window.addEventListener('scroll', function() {
    if (window.scrollY >= sec1.offsetTop) {
        if (window.scrollY > lastScrollY) {
            header.style.top = "-180px";
        } else {
        header.style.top = "0";
        }
    }
    lastScrollY = window.scrollY;
});




const feedList = document.querySelector('.feed_list');
const feeds = document.querySelectorAll('.feed');

// 간격을 지정 (예: 10px)
const gap = 8;

function masonLayout() {
  // 각 feed 요소들의 너비를 계산하고, 그에 맞춰 열의 수를 계산
  const columnCount = Math.floor(feedList.offsetWidth / (feeds[0].offsetWidth + gap));  // 열 간격을 고려해서 계산
  const columns = new Array(columnCount).fill(0);  // 각 열의 현재 높이를 저장하는 배열

  // feeds의 모든 요소를 순차적으로 배치
  feeds.forEach((feed, index) => {
    // 열 번호를 순차적으로 결정
    const column = index % columnCount; // 열은 0부터 columnCount-1까지 순차적으로 배치

    // feed의 위치를 해당 열에 배치
    feed.style.top = columns[column] + 'px';  // 각 열의 가장 끝 부분에 배치
    feed.style.left = `${column * (feed.offsetWidth + gap)}px`;  // 열의 위치는 column 번호에 따라 계산, 간격을 추가

    // 해당 열의 높이를 업데이트
    columns[column] += feed.offsetHeight + gap;  // 해당 열의 높이를 feed의 높이와 간격만큼 증가시킴
  });

  // feed_list의 높이를 설정하여 레이아웃이 제대로 보이게 함
  feedList.style.height = `${Math.max(...columns)}px`;  // 가장 높은 열의 높이를 설정하여 feed_list가 스크롤되지 않게 함
  
  // feed_list를 수평 중앙 정렬하기 위해 left 값을 계산
  const totalWidth = columnCount * (feeds[0].offsetWidth + gap) - gap;  // 전체 너비
  const marginLeft = (feedList.offsetWidth - totalWidth) / 2;  // 남는 공간을 양옆에 분배

  // feed_list에 margin-left를 설정하여 중앙 정렬
  feedList.style.marginLeft = `${marginLeft}px`;
}

// 페이지 로드 및 리사이즈 시마다 레이아웃 재조정
window.addEventListener('load', masonLayout);
window.addEventListener('resize', masonLayout);
